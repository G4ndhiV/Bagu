//
//  Prototype1App.swift
//  Prototype1
//
//  Created by Josue Galindo on 29/08/24.
//

import SwiftUI

@main
struct Prototype1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
